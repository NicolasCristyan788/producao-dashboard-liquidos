from flask import Flask, render_template, request, redirect, url_for, session
import json
import pandas as pd
import plotly.graph_objs as go
from plotly.utils import PlotlyJSONEncoder

app = Flask(__name__)
app.secret_key = "rejunte3030"
EXCEL_PATH = 'producaoliquidos.xlsx'

def load_production_from_excel(file_path=EXCEL_PATH):
    try:
        df = pd.read_excel(file_path, engine='openpyxl')
        return {
            'meta_ideal_f01': int(df.loc[0, 'meta_ideal_f01']),
            'producao_atual_f01': int(df.loc[0, 'producao_atual_f01']),
            'meta_ideal_f18': int(df.loc[0, 'meta_ideal_f18']),
            'producao_atual_f18': int(df.loc[0, 'producao_atual_f18']),
            'meta_ideal_pouch': int(df.loc[0, 'meta_ideal_pouch']),
            'producao_atual_pouch': int(df.loc[0, 'producao_atual_pouch']),
            'meta_ideal_tambores': int(df.loc[0, 'meta_ideal_tambores']),
            'producao_atual_tambores': int(df.loc[0, 'producao_atual_tambores']),
            'meta_ideal_rejuntes': int(df.loc[0, 'meta_ideal_rejuntes']),
            'producao_atual_rejuntes': int(df.loc[0, 'producao_atual_rejuntes']),
            'meta_ideal_liquidos': int(df.loc[0, 'meta_ideal_liquidos']),
            'producao_atual_liquidos': int(df.loc[0, 'producao_atual_liquidos'])
        }
    except Exception as e:
        print("Erro ao ler Excel:", e)
        return None

def save_production_to_excel(data, file_path=EXCEL_PATH):
    try:
        df = pd.DataFrame([data])
        df.to_excel(file_path, index=False)
    except Exception as e:
        print("Erro ao salvar no Excel:", e)

@app.route('/')
def index():
    prod = load_production_from_excel()
    if prod is None:
        return "Erro ao carregar dados da planilha Excel", 500

    tipos = [
        ('F01', 'f01'),
        ('F18', 'f18'),
        ('Pouch', 'pouch'),
        ('Tambores', 'tambores'),
        ('Rejuntes', 'rejuntes'),
        ('Líquidos', 'liquidos')
    ]

    categorias = []
    metas = []
    producoes = []
    cores_producao = []

    for nome, tipo in tipos:
        meta = prod[f'meta_ideal_{tipo}']
        atual = prod[f'producao_atual_{tipo}']
        progresso = atual / meta if meta > 0 else 0

        categorias.append(nome)
        metas.append(meta)
        producoes.append(atual)

        cor = '#e53935' if progresso < 0.5 else '#fbc02d' if progresso < 1.0 else '#43a047'
        cores_producao.append(cor)

    trace_metas = go.Bar(
        x=categorias,
        y=metas,
        name='Meta',
        marker=dict(color="#66b3f3"),
        text=[f"Meta: {m}" for m in metas],
        textposition='auto'
    )

    trace_producoes = go.Bar(
        x=categorias,
        y=producoes,
        name='Produção',
        marker=dict(color=cores_producao),
        text=[f"{v} ({(v/m)*100:.1f}%)" if m > 0 else "0" for v, m in zip(producoes, metas)],
        textposition='auto'
    )

    fig = go.Figure(data=[trace_metas, trace_producoes])

    fig.update_layout(
        template='plotly_white',
        barmode='group',
        bargap=0.25,
        bargroupgap=0.05,
        uniformtext_minsize=8,
        uniformtext_mode='hide',
        autosize=True,
        margin=dict(l=50, r=30, t=80, b=80),
        title_text='Gráfico de Produção',
        title_font=dict(family='Poppins', size=32),
        title_x=0.5,
        xaxis=dict(
            title='Linha de Produção',
            tickangle=-15,
            title_font=dict(family="Poppins", size=18),
            tickfont=dict(family="Poppins", size=14)
        ),
        yaxis=dict(
            title='Quantidade',
            type='log',
            title_font=dict(family="Poppins", size=18),
            tickfont=dict(family="Poppins", size=14),
            gridcolor='lightgray'
        ),
        font=dict(family="Poppins", size=14),
        showlegend=True,
        plot_bgcolor='white',
        paper_bgcolor='white',
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
    )

    graphJSON = json.dumps(fig, cls=PlotlyJSONEncoder)

    return render_template(
        'index.html',
        graphJSON=graphJSON,
        meta_f01=prod['meta_ideal_f01'],
        atual_f01=prod['producao_atual_f01'],
        meta_f18=prod['meta_ideal_f18'],
        atual_f18=prod['producao_atual_f18'],
        meta_pouch=prod['meta_ideal_pouch'],
        atual_pouch=prod['producao_atual_pouch'],
        meta_tambores=prod['meta_ideal_tambores'],
        atual_tambores=prod['producao_atual_tambores'],
        meta_rejuntes=prod['meta_ideal_rejuntes'],
        atual_rejuntes=prod['producao_atual_rejuntes'],
        meta_liquidos=prod['meta_ideal_liquidos'],
        atual_liquidos=prod['producao_atual_liquidos']
    )

@app.route('/editar', methods=['GET', 'POST'])
def editar():
    if not session.get('logado'):
        return redirect(url_for('login'))

    campos = [
        'meta_ideal_f01', 'producao_atual_f01',
        'meta_ideal_f18', 'producao_atual_f18',
        'meta_ideal_pouch', 'producao_atual_pouch',
        'meta_ideal_tambores', 'producao_atual_tambores',
        'meta_ideal_rejuntes', 'producao_atual_rejuntes',
        'meta_ideal_liquidos', 'producao_atual_liquidos'
    ]

    prod = load_production_from_excel() or {campo: 0 for campo in campos}

    if request.method == 'POST':
        try:
            dados = {campo: int(request.form.get(campo, 0)) for campo in campos}
            save_production_to_excel(dados)
            return redirect(url_for('index'))
        except ValueError:
            pass

    return render_template('editar.html', **prod)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        if request.form.get('senha') == 'quartzolit123':
            session['logado'] = True
            return redirect(url_for('editar'))
        else:
            return render_template('login.html', erro="Senha incorreta!")
    return render_template('login.html', erro=None)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5030, debug=True, use_reloader=False)